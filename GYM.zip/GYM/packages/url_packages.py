from django.conf.urls import url
from packages import views

urlpatterns = [

   url('^$', views.packages, name="packages"),
   url('^view/', views.viewpkg,name="viewpkg"),
]
