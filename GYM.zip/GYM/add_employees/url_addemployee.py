from django.conf.urls import url
from add_employees import views

urlpatterns = [
     url('^$', views.add_employees,name="add_employees"),
     url('^view/', views.viewemp,name="viewemp"),
]
