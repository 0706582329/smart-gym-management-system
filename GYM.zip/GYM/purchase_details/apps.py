from django.apps import AppConfig


class PurchaseDetailsConfig(AppConfig):
    name = 'purchase_details'
