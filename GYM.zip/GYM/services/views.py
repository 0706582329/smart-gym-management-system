from django.shortcuts import render
from django.http import  HttpResponse
from services.models import Services

# Create your views here.
def viewservice(request):
    objlist=Services.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'services/viewservice.html',context)

def services(request):
    if request.method == "POST":
        obj = Services()
        obj.name = request.POST.get('name')
        obj.description = request.POST.get('discription')



        obj.save()


    return render(request, 'services/service.html')