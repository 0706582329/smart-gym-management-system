from django.apps import AppConfig


class AddAssetConfig(AppConfig):
    name = 'add_asset'
