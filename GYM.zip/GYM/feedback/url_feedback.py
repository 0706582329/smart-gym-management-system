from django.conf.urls import url
from feedback import views

urlpatterns = [
url('^$', views.feedback,name="feedback")

]
