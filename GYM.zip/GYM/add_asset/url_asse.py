from django.conf.urls import url
from add_asset import views

urlpatterns=[
    url('^$', views.add_asset,name="add_asset"),
    url('^view/', views.viewasset,name="viewasset"),
]
