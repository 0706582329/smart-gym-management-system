from django.conf.urls import url
from selected_packages import views

urlpatterns = [

]
