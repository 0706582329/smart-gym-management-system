from django.shortcuts import render
from django.http import HttpResponse
from add_employees.models import Addemployee
from login.models import Login
import datetime
from django.db.models import Max


def viewemp(request):
    objlist=Addemployee.objects.all()
    context={
        'objval':objlist,

    }
    return render(request, 'add_employees/viewemp.html', context)
def add_employees(request):

    if request.method == "POST":
        obj = Addemployee()

        ob = Login()
        sid = Addemployee.objects.all().aggregate(Max('eid'))
        sidd = list(sid.values())[0]
        siddv = ''

        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0

        obj.eid = sidd + 1
        ob.uid = sidd + 1
        ob.username = request.POST.get('email')
        ob.password = request.POST.get('pass')
        ob.type = "employee"
        ob.save()

        obj.name = request.POST.get('uname')
        obj.email = request.POST.get('email')
        obj.address = request.POST.get('address')
        obj.phone = request.POST.get('Phone')
        obj.experience = request.POST.get('experience')
        obj.gender = request.POST.get('Gender')
        obj.dob = request.POST.get('dob')


        obj.save()

    return render(request, 'add_employees/addemployee.html')