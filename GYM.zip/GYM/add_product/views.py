from django.shortcuts import render
from django.http import  HttpResponse
from add_product.models import Addproduct

# Create your views here.
def viewproduct(request):
    objlist=Addproduct.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'add_product/viewproduct.html',context)

def add_product(request):
    if request.method == "POST":
        obj = Addproduct()
        obj.type = request.POST.get('types')
        obj.name = request.POST.get('name')
        obj.price = request.POST.get('price')
        obj.expdate = request.POST.get('exp')


        obj.save()


    return render(request, 'add_product/addproduct.html')