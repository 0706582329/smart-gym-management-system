from django.conf.urls import url
from user_reg import views

urlpatterns = [

    url('^$', views.user_reg,name="user_reg"),
    url('^view/', views.viewuser, name="viewuser")
    ]
