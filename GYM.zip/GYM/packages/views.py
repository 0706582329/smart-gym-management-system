from django.shortcuts import render
from django.http import HttpResponse
from packages.models import Packages


# Create your views here.
def viewpkg(request):
    objlist=Packages.objects.all()
    context={
        'objval':objlist,

    }
    return render(request, 'packages/viewpkg.html', context)
def packages(request):
    if request.method=="POST":
        obj=Packages()
        obj.name=request.POST.get('name')
        obj.charge=request.POST.get('amount')
        obj.duration=request.POST.get('duration')
        obj.save()
    return render(request, 'packages/addpackage.html')