from django.conf.urls import url
from purchase_details import views

urlpatterns = [

]
