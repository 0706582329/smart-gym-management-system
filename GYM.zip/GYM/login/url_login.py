from django.conf.urls import url
from login import views

urlpatterns = [

    url('^$', views.login, name="login"),
    url('^index/', views.index, name="index"),
    url('^adminhome/', views.adminhome, name="adminhome"),
    url('^userhome/', views.userhome, name="userhome"),
    url('^employee/', views.employee, name="employee"),
]
