from django.shortcuts import render
from login.models import Login
# Create your views here.
def login(request):
    if request.method == "POST":
        uname = request.POST.get("uname")
        passw = request.POST.get("pass")

        obj = Login.objects.filter(username=uname, password=passw)
        tp = ""
        for ob in obj:
            tp = ob.type
            uid = ob.uid
            if tp == "admin":
                request.session['uid'] = uid

                return render(request, 'login/adminhome.html')
            elif tp == "employee":
                request.session['uid'] = uid
                return render(request, 'login/employee.html')


            elif tp == "user":
                request.session['uid'] = uid
                return render(request, 'login/userhome.html')




            else:
                return render(request, 'login/login.html')

    return render(request, 'login/login.html')
    # return HttpResponse("login")

    return render(request, 'login/login.html')
def index(request):
    return render(request, 'login/indexhome.html')
def adminhome(request):
    return render(request, 'login/adminhome.html')
def userhome(request):
    return render(request, 'login/userhome.html')
def employee(request):
    return render(request, 'login/employee.html')