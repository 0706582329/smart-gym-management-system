from django.apps import AppConfig


class AddEmployeesConfig(AppConfig):
    name = 'add_employees'
