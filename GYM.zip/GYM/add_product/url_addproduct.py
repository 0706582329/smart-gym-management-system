from django.conf.urls import url
from add_product import views

urlpatterns = [
   url('^$', views.add_product,name="add_product"),
   url('^view/', views.viewproduct,name="viewproduct")

]


