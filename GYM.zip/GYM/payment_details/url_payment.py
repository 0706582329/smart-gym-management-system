from django.conf.urls import url
from payment_details import views

urlpatterns = [

]
