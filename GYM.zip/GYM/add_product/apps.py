from django.apps import AppConfig


class AddProductConfig(AppConfig):
    name = 'add_product'
