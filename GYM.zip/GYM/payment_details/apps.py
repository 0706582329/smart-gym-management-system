from django.apps import AppConfig


class PaymentDetailsConfig(AppConfig):
    name = 'payment_details'
