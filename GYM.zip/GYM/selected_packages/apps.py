from django.apps import AppConfig


class SelectedPackagesConfig(AppConfig):
    name = 'selected_packages'
