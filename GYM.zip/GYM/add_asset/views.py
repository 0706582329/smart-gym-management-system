from django.shortcuts import render
from django.http import HttpResponse
from add_asset.models import Addasset

# Create your views here.
def viewasset(request):
    objlist=Addasset.objects.all()
    context={
        'objval':objlist,

    }
    return render(request, 'add_asset/viewasset.html', context)
def add_asset(request):
    if request.method=="POST":
        obj=Addasset()
        obj.type=request.POST.get('types')
        obj.name=request.POST.get('asset')
        obj.purchasedate=request.POST.get('purchasedate')
        obj.servicedate=request.POST.get('servicedate')
        obj.status=request.POST.get('status')
        obj.save()

    return render(request, 'add_asset/addasset.html')