from django.conf.urls import url
from services import views

urlpatterns = [
    url('^$', views.services, name="services"),
    url('^view/', views.viewservice, name="viewservice"),
]
