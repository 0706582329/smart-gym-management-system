from django.shortcuts import render
from django.http import HttpResponse
from user_reg.models import Userregistration
from login.models import Login
import datetime
from django.db.models import Max
# Create your views here.
def viewuser(request):
    objlist=Userregistration.objects.all()
    context={
        'objval':objlist,

    }
    return render(request, 'user_reg/viewuser.html', context)
def user_reg(request):
    if request.method == "POST":
        obj = Userregistration()

        ob = Login()
        sid = Userregistration.objects.all().aggregate(Max('uid'))
        sidd = list(sid.values())[0]
        siddv = ''

        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0

        obj.uid = sidd + 1
        ob.uid = sidd + 1
        ob.username = request.POST.get('email')
        ob.password = request.POST.get('pass')
        ob.type = "user"
        ob.save()


        obj.username = request.POST.get('uname')
        obj.email = request.POST.get('email')
        obj.phone = request.POST.get('Phone')
        obj.address = request.POST.get('address')
        obj.dob = request.POST.get('dob')
        obj.height = request.POST.get('height')
        obj.status = request.POST.get('status')
        obj.weight = request.POST.get('weight')
        obj.bloodgroup = request.POST.get('Blood')
        obj.photo = request.POST.get('filename')

        obj.save()

    return render(request, 'user_reg/usrregistration.html')

